#pragma once

/// Ensures GLEW loaded before GLFW
#include <OpenGP/GL/gl.h>
#include <GLFW/glfw3.h>
