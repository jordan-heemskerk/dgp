#!/bin/bash
mkdir -p /Users/jheems/bin
cp ./screen ./.vimrc /Users/jheems/bin

export PATH=/Users/jheems/bin:$PATH
